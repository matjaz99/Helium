package si.matjazcerkvenik.helium.html;

public class Attribute {
	
	/* GLOBAL ATTRIBUTES */
	/** Unique id for an element */
	public static final String ID = "id";

	/**
	 * One or more classnames for an element (refers to a class in a style
	 * sheet)
	 */
	public static final String CLASS = "class";

	/** Language of the element's content */
	public static final String LANG = "lang";

	/** Inline CSS style for an element */
	public static final String STYLE = "style";

	/** Information about an element */
	public static final String TITLE = "title";

	/* EVENT ATTRIBUTES */
	/** Fires after the page is finished loading */
	public static final String ONLOAD = "onload";

	/** Fires once a page has unloaded (or the browser window has been closed) */
	public static final String ONUNLOAD = "onunload";

	/** Fires on a mouse click on the element */
	public static final String ONCLICK = "onclick";

	/** Fires when a mouse button is pressed down on an element */
	public static final String ONMOUSEDOWN = "onmousedown";

	/** Fires when the mouse pointer moves out of an element */
	public static final String ONMOUSEOUT = "onmouseout";

	/** Fires when the mouse pointer moves over an element */
	public static final String ONMOUSEOVER = "onmouseover";

	/** Fires when a mouse button is released over an element */
	public static final String ONMOUSEUP = "onmouseup";
}
