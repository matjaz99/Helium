package si.matjazcerkvenik.helium.css;

public class BackgroundRepeat {
	
	public static final String no_repeat = "no-repeat";
	public static final String repeat = "repeat";
	public static final String repeat_x = "repeat-x";
	public static final String repeat_y = "repeat-y";
	
}
