package si.matjazcerkvenik.helium.html;

import si.matjazcerkvenik.helium.HtmlElement;

public class Article extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "article";
	}
	
}
