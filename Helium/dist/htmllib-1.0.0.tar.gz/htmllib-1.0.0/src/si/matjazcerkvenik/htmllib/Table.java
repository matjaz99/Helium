package si.matjazcerkvenik.htmllib;

import java.util.ArrayList;
import java.util.List;

public class Table extends HtmlElement {
	
	public static final String ATTR_BORDER = "border";
	private List<Tr> rows = null;
	
	/**
	 * Default constructor for html table. By default 
	 * value for border is set to 1.
	 */
	public Table() {
		setBorder(1);
	}
	
	/**
	 * Add new entry. Each new entry creates new row.
	 * @param row
	 */
//	public void addRow(List<Object> row) {
//		
//		if (rows == null) {
//			rows = new ArrayList<Tr>();
//		}
//		Tr tr = new Tr();
//		tr.setRow(row);
//		rows.add(tr);
//		
//	}
	
	public void addRow(Tr row) {
		
		if (rows == null) {
			rows = new ArrayList<Tr>();
		}
		rows.add(row);
		
	}
	
	
	
	public int getBorder() {
		return Integer.parseInt(getAttributes().get(ATTR_BORDER));
	}

	public void setBorder(int border) {
		addAttribute(ATTR_BORDER, Integer.toString(border));
	}

	@Override
	public String toString() {
		if (rows == null) {
			return "";
		}
		if (rows.get(0).getCols() == null) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("<table ");
		sb.append(getAttributesAsString());
		sb.append(">");
		for (int i = 0; i < rows.size(); i++) {
			sb.append(rows.get(i).toString());
		}
		sb.append("</table>\n");
		return sb.toString();
	}
	
}
