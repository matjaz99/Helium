package si.matjazcerkvenik.htmllib;


public class Form extends HtmlElement {
	
	public static final String ATTR_ACTION = "action";
	public static final String ATTR_METHOD = "method";
	
	
	public Form() {
	}
	
	public Form(String action, String method) {
		addAttribute(ATTR_ACTION, action);
		addAttribute(ATTR_METHOD, method);
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<form " + getAttributesAsString() + ">");
		sb.append(getElementsAsString());
		sb.append("</form>");
		return sb.toString();
	}
	
}
