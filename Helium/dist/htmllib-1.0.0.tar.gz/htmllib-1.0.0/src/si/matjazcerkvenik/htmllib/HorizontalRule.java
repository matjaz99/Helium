package si.matjazcerkvenik.htmllib;

public class HorizontalRule extends HtmlElement {
	
	@Override
	public String toString() {
		return "<hr>";
	}
	
}
