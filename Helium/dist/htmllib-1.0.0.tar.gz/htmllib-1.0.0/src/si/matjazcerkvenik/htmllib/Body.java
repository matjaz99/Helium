package si.matjazcerkvenik.htmllib;


public class Body extends HtmlElement {

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<body>");
		for (int i = 0; i < getElements().size(); i++) {
			sb.append(getElements().get(i).toString());
		}
		sb.append("</body>");
		return sb.toString();
	}

}
