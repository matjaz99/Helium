package si.matjazcerkvenik.htmllib;

public class Heading extends HtmlElement {
	
	private int level = 1;
	
	public Heading() {
	}
	
	public Heading(int level) {
		this.level = level;
	}
	
	public Heading(int level, String text) {
		this.level = level;
		addHtmlElement(new NoElement(text));
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
	
	@Override
	public String toString() {
		return "<h" + level + ">" + getElementsAsString() //getValue().toString() 
				+ "</h" + level + ">";
	}
	
}
