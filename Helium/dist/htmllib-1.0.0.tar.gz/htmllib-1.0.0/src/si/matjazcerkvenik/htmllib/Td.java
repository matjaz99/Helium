package si.matjazcerkvenik.htmllib;

public class Td extends HtmlElement {
	
	@Override
	public String toString() {
		return "<td>" + getElementsAsString() + "</td>";
	}
	
	
}
