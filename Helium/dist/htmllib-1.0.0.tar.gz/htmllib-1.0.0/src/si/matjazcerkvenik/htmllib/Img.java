package si.matjazcerkvenik.htmllib;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Img extends HtmlElement {
	
	public static final String ATTR_SRC = "src";
	
	private byte[] fileData;
	
	public Img() {
	}
	
	public Img(String src) {
		File f = new File(src);
		setSource(src);		
		
		int fileLength = (int) f.length();
		
		FileInputStream fileIn = null;

		fileData = new byte[fileLength];

		try {
			fileIn = new FileInputStream(f);
			fileIn.read(fileData);
			fileIn.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void setSource(String src) {
		addAttribute(ATTR_SRC, src);
	}
	
	@Override
	public String toString() {
		return "<img " + getAttributesAsString() + " />";
	}
	
}
