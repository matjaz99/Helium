package si.matjazcerkvenik.htmllib;

public class NoElement extends HtmlElement {
	
	private String text = null;

	public NoElement(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
	@Override
	public String toString() {
		return text;
	}
	

}
