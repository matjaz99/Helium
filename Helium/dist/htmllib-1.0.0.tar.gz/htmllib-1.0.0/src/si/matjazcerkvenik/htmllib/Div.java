package si.matjazcerkvenik.htmllib;

public class Div extends HtmlElement {
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<div " + getAttributesAsString() + ">");
		sb.append(getElementsAsString());
		sb.append("</div>");
		return sb.toString();
	}
	
}
