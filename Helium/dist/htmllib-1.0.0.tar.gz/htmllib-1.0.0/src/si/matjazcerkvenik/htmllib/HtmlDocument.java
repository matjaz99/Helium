package si.matjazcerkvenik.htmllib;


public class HtmlDocument {
	
	private Head head = null;
	private Body body = null;
	
	
	public HtmlDocument() {
	}

	public HtmlDocument(Head head, Body body) {
		this.head = head;
		this.body = body;
	}
	
	
	public Head getHead() {
		return head;
	}

	public void setHead(Head head) {
		this.head = head;
	}

	public Body getBody() {
		return body;
	}

	public void setBody(Body body) {
		this.body = body;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<html>");
		sb.append(head.toString());
		sb.append(body.toString());
		sb.append("</html>");
		return sb.toString();
	}
	
}
