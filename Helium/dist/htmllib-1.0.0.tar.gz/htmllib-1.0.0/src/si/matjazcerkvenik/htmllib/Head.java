package si.matjazcerkvenik.htmllib;

public class Head extends HtmlElement {
	
	private String title = "title";
	
	public Head() {
	}
	
	public Head(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<head>");
		sb.append("<title>" + title + "</title>");
		sb.append("</head>");
		return sb.toString();
	}
	
}
