package si.matjazcerkvenik.htmllib;


/**
 * Usually used to declare stylesheet.
 * @author matjaz
 *
 */
public class Link extends HtmlElement {
	
	public static final String ATTR_REL = "rel";
	public static final String ATTR_TYPE = "type";
	public static final String ATTR_HREF = "href";
	
	
	public Link() {
	}
	
	/**
	 * Set path to CSS file relative to web directory.
	 * @param cssFile
	 */
	public Link(String styleSheet) {
		addAttribute(ATTR_REL, "stylesheet");
		addAttribute(ATTR_TYPE, "text/css");
		addAttribute(ATTR_HREF, styleSheet);
	}
	
	@Override
	public String toString() {
		return "<link " + getAttributesAsString() + "/>";
	}
	
}
