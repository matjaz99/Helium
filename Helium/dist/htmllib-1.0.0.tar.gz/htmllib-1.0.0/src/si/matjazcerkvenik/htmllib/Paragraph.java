package si.matjazcerkvenik.htmllib;

public class Paragraph extends HtmlElement {
	
	public static final String ATTR_ALIGN = "align";
	
	public Paragraph(String text) {
//		setValue(text);
		addHtmlElement(new NoElement(text));
	}
	
	@Override
	public String toString() {
		return "<p>" + getElementsAsString() + "</p>";
	}
	
}
