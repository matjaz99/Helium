package si.matjazcerkvenik.htmllib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class HtmlElement {
	
	/* global attributes */
	public static final String ATTR_ID = "id";
	public static final String ATTR_CLASS = "class";
	public static final String ATTR_LANG = "lang";
	public static final String ATTR_STYLE = "style";
	public static final String ATTR_TITLE = "title";
	
	/* event attributes */
	public static final String ATTR_ONLOAD = "onload";
	public static final String ATTR_ONUNLOAD = "onunload";
	
	/* list of all attributes */
	private Map<String, String> attributes = null;
	
	/* value - what is inside element */
//	private Object value = null;
	
	private List<HtmlElement> elements = null;

	/**
	 * Add child element
	 * @param e
	 * @return HtmlElement
	 */
	public HtmlElement addHtmlElement(HtmlElement e) {

		if (elements == null) {
			elements = new ArrayList<HtmlElement>();
		}

		elements.add(e);
		
		return this;

	}
	
	
	/**
	 * Get all child elements
	 * @return elements
	 */
	public List<HtmlElement> getElements() {
		return elements;
	}



	/**
	 * Add new attribute to element.
	 * @param attrName
	 * @param attrValue
	 */
	public void addAttribute(String attrName, String attrValue) {
		if (attributes == null) {
			attributes = new HashMap<String, String>();
		}
		attributes.put(attrName, attrValue);
	}
	
	/**
	 * Return all attributes
	 * @return attributes
	 */
	public Map<String, String> getAttributes() {
		return attributes;
	}
	
	/**
	 * Return all attributes in key="value" format
	 * @return attributes
	 */
	public String getAttributesAsString() {
		if (attributes == null || attributes.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (String key : attributes.keySet()) {
			sb.append(key + "=\"" + attributes.get(key) + "\" ");
		}
		return sb.toString();
	}
	
	/**
	 * Return all elements as string
	 * @return elements
	 */
	public String getElementsAsString() {
//		if (value != null) {
//			return value.toString();
//		}
		if (elements == null || elements.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < elements.size(); i++) {
			sb.append(elements.get(i).toString());
		}
		return sb.toString();
	}
	
	/**
	 * Value can either be 
	 * String or HtmlElement or any other object that has 
	 * toString method implemented. 
	 * @param o
	 */
//	public void setValue(Object o) {
//		if (o instanceof HtmlElement) {
//			addHtmlElement((HtmlElement) o);
//			return;
//		}
//		value = o;
//	}
	
//	public Object getValue() {
//		return value;
//	}
	
}
