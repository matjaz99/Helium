package si.matjazcerkvenik.htmllib;

public class Input extends HtmlElement {
	
	public static final String ATTR_TYPE = "type";
	public static final String ATTR_NAME = "name";
	
	public enum TYPE { BUTTON, CHECKBOX, FILE, HIDDEN, IMAGE, PASSWORD,
		RADIO, RESET, SUBMIT, TEXT };
	
//	private TYPE inputType = TYPE.TEXT;
	
	public Input() {
	}
	
	public Input(TYPE type, String name) {
		addAttribute(ATTR_TYPE, type.name().toLowerCase());
		addAttribute(ATTR_NAME, name);
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<div " + getAttributesAsString() + ">");
		sb.append(getElementsAsString());
		sb.append("</div>");
		return sb.toString();
	}
	
}
