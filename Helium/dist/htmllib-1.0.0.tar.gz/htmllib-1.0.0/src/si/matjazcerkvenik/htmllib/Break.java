package si.matjazcerkvenik.htmllib;

public class Break extends HtmlElement {
	
	@Override
	public String toString() {
		return "<br>";
	}
	
}
