package si.matjazcerkvenik.htmllib;


public class Anchor extends HtmlElement {
	
	public static final String ATTR_HREF = "href";
	public static final String ATTR_HREFLANG = "hreflang";
	
	public Anchor() {
	}
	
	public Anchor(String url) {
		setHref(url);
	}
	
	public Anchor(String url, HtmlElement e) {
		setHref(url);
		addHtmlElement(e);
	}
	
	/**
	 * Add <code>href</code> attribute for given url.<br>
	 * This is simplified version of addAttribute method.
	 * The same can be achieved by calling 
	 * <code>addAttribute(Anchor.ATTR_HREF, "http://...")</code> 
	 * method.
	 * @param url
	 */
	public void setHref(String url) {
		addAttribute(ATTR_HREF, url);
	}
	
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<a ");
		sb.append(getAttributesAsString());
		sb.append(">");
		sb.append(getElementsAsString());
		sb.append("</a>");
		return sb.toString();
	}
	
}
