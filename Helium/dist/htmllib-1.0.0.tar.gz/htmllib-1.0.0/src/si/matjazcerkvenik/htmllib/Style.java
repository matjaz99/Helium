package si.matjazcerkvenik.htmllib;


public class Style extends HtmlElement {
	
	public static final String ATTR_TYPE = "type";
	
	
	@Override
	public String toString() {
		return "<style " + getAttributesAsString() + ">"
				+ getElementsAsString() + "</style>";
	}
	
}
