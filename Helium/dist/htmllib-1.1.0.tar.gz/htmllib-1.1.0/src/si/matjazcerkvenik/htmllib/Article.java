package si.matjazcerkvenik.htmllib;

public class Article extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "article";
	}
	
}
