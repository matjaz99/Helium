package si.matjazcerkvenik.htmllib;

public class Footer extends HtmlElement {
	
	public Footer() {
	}
	
	public Footer(HtmlElement... eList) {
		for (int i = 0; i < eList.length; i++) {
			addElement(eList[i]);
		}
	}
	
	@Override
	public String getTagName() {
		return "footer";
	}
	
}
