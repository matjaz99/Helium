package si.matjazcerkvenik.htmllib;

/**
 * Simple <code>&lt;hr&gt;</code> element.<br>
 * This element cannot accept any child elements.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Hr extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "hr";
	}
	
	@Override
	public String toString() {
		return "<hr" + getAttributesAsString() + "/>";
	}
	
}
