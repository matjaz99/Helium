package si.matjazcerkvenik.htmllib;

public class Aside extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "aside";
	}
	
}
