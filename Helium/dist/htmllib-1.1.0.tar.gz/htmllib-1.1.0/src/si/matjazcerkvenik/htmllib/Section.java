package si.matjazcerkvenik.htmllib;

public class Section extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "section";
	}
	
}
