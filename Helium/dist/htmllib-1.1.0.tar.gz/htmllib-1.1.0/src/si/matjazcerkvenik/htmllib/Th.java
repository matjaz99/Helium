package si.matjazcerkvenik.htmllib;

/**
 * This element must be used in conjunction with table and tr element.
 * 
 * @author matjaz
 *
 */
public class Th extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "th";
	}
	
}
