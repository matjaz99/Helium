package si.matjazcerkvenik.htmllib;

/**
 * This class represents <code>&lt;strong&gt;</code> element.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Strong extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "strong";
	}
	
}
