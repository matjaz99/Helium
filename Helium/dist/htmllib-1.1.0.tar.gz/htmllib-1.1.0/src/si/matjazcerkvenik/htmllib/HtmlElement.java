package si.matjazcerkvenik.htmllib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import si.matjazcerkvenik.htmllib.css.CssStyle;

/**
 * Abstract representation of HTML element. Each HTML element consists of 
 * attributes and one or more child elements.<br>
 * This class cannot be instanced because it is abstract. Instead you must 
 * instance concrete class that represents concrete HTML element 
 * (eg. Div).<br>
 * This class provides methods for adding child elements and setting 
 * attributes.
 * 
 * @author Matjaž Cerkvenik
 *
 */
public abstract class HtmlElement {
	
	// http://www.w3schools.com/tags/default.asp
	
	/* list of attributes of this element */
	private Map<String, String> attributes = new HashMap<String, String>();
	
	/* list of child elements */
	private List<HtmlElement> elements = new ArrayList<HtmlElement>();
	
	/** a counter of elements; used for automatic assigning of IDs */
	public static int elementCounter = 0;
	
	protected List<CssStyle> cssStyles = new ArrayList<CssStyle>();
	
	/**
	 * Return name of HTML element.
	 * @return name
	 */
	public abstract String getTagName();
	
	/**
	 * Get element id. If id is not already assigned, it will 
	 * be automatically generated when this method is called.
	 * @return id
	 */
	public String getId() {
		String id = attributes.get(Attribute.ID);
		if (id == null) {
			setId("e" + elementCounter++);
		}
		return attributes.get(Attribute.ID);
	}

	/**
	 * Manually set element ID. You must apply ID 
	 * before applying any style, because CSS styles are generated 
	 * on the basis of ID. Once the style is added, ID may not be changed!<br>
	 * Anyway, HtmlLib is designed in this way, that the user does not need 
	 * to take care of IDs, unless necessary. HtmlLib automatically 
	 * assigns IDs to elements when needed.
	 * @param id
	 */
	public void setId(String id) {
		addAttribute(Attribute.ID, id);
	}



	/**
	 * Add child element
	 * @param e
	 * @return HtmlElement
	 */
	public HtmlElement addElement(HtmlElement... e) {
		for (int i = 0; i < e.length; i++) {
			elements.add(e[i]);
		}
		return this;

	}
	
	
	/**
	 * Get all child elements
	 * @return elements
	 */
	public List<HtmlElement> getElements() {
		return elements;
	}



	/**
	 * Add attribute to element. If attribute with the same name 
	 * already exist, its value will be overwritten with new one.<br>
	 * Remark: to modify existing attribute, first read attribute, modify 
	 * it then save it back as new parameter.
	 * @param attrName
	 * @param attrValue
	 */
	public void addAttribute(String attrName, String attrValue) {
		attributes.put(attrName, attrValue);
	}
	
	/**
	 * Append new value of the attribute. If attribute does not exist 
	 * yet, it will be added (the same as addAttribute method). If 
	 * attribute already exists, new value will be appended to that 
	 * attribute.
	 * @param attrName
	 * @param attrValue
	 */
	public void appendAttribute(String attrName, String attrValue) {
		String v = attributes.get(attrName);
		if (v == null) {
			attributes.put(attrName, attrValue);
		} else {
			v += " " + attrValue;
			attributes.put(attrName, v);
		}
	}
	
	/**
	 * Return all attributes
	 * @return attributes
	 */
	public Map<String, String> getAttributes() {
		return attributes;
	}
	
	/**
	 * Return list of all CSS styles for this element
	 * @return cssStyles
	 */
	public List<CssStyle> getCssStyles() {
		return cssStyles;
	}
	
	
	
	
	
	/* *********** */
	/*   STYLING   */
	/* *********** */
	
	
	
	

	/**
	 * Set style for this element. Style is put inside &lt;style&gt; element.
	 * @param css
	 */
	public void setStyle(CssStyle... style) {
		
		for (int i = 0; i < style.length; i++) {
			
			if (style[i].getSelector() == null) {
				
				System.out.println("style is NULL !!!!!!!!!!!!!!!!!!!!!!!!!!!");
//				style[i].setSelector("." + style[i].getStyleId());
//				appendAttribute(Attribute.CLASS, style[i].getStyleId());
				style[i].setSelector(getTagName());
				
			} else if (style[i].getSelector().startsWith("#")) {
				
				addAttribute(Attribute.ID, getId());
				
			} else if (style[i].getSelector().startsWith(".")) {
				
				appendAttribute(Attribute.CLASS, style[i].getStyleId());
				
			} else {
				
//				style[i].setSelector(getTagName());
				
			}
			cssStyles.add(style[i]);
			
		}
		
		
	}
	
	
	
	
	
	
	/* ****************** */
	/*   PREPARE OUTPUT   */
	/* ****************** */
	
	
	
	
	
	/**
	 * Return string representation of all attributes in key="value" format.
	 * If no attributes are found, empty string is returned.
	 * @return attributes
	 */
	public String getAttributesAsString() {
		
		if (attributes.isEmpty()) return "";
		
		StringBuilder sb = new StringBuilder();
		for (String key : attributes.keySet()) {
			sb.append(key + "=\"" + attributes.get(key) + "\" ");
		}
		return " " + sb.toString();
	}
	
	/**
	 * Return string representation of child elements.
	 * @return elements
	 */
	public String getElementsAsString() {
		
		if (elements.isEmpty()) return "";
		
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < elements.size(); i++) {
			String s = elements.get(i).toString();
			sb.append(s);
		}
		return sb.toString();
	}
	
	/**
	 * Return list of CssStyles of this and all child elements.
	 * @return elStyles
	 */
	public List<CssStyle> toList() {
		
		List<CssStyle> elStyles = new ArrayList<CssStyle>();
		elStyles.addAll(cssStyles);
		elStyles.addAll(getAllCssStyles());
		
		return elStyles;
		
	}
	
	/**
	 * Return list of styles of all child elements.
	 * @return elStyles
	 */
	public List<CssStyle> getAllCssStyles() {
		
		List<CssStyle> elStyles = new ArrayList<CssStyle>();
		
		if (elements.isEmpty()) return elStyles;
		
		for (int i = 0; i < elements.size(); i++) {
			elStyles.addAll(elements.get(i).toList());
		}
		return elStyles;
	}

	
	/**
	 * Return string representation of this and all child elements.
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<").append(getTagName());
		sb.append(getAttributesAsString());
		sb.append(">\n");
		sb.append(getElementsAsString());
		sb.append("</").append(getTagName()).append(">\n");
		return sb.toString();
	}
	
	
}
