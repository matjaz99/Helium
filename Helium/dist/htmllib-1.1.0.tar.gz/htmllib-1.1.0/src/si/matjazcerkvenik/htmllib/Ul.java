package si.matjazcerkvenik.htmllib;

/**
 * This class represents <code>&lt;ul&gt;</code> element. This element 
 * accepts any element as child element. Usually it is used as wrapper for 
 * other elements.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Ul extends HtmlElement {
	
	public Ul() {
	}
	
	public Ul(HtmlElement... eList) {
		for (int i = 0; i < eList.length; i++) {
			addElement(eList[i]);
		}
	}
	
	@Override
	public String getTagName() {
		return "ul";
	}
	
}
