package si.matjazcerkvenik.htmllib;

public class Figure extends HtmlElement {
	
	@Override
	public String getTagName() {
		return "figure";
	}
	
}
