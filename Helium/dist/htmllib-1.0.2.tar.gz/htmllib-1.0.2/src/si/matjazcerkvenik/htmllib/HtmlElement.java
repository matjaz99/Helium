package si.matjazcerkvenik.htmllib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Abstract representation of HTML element. Each HTML element consists of 
 * attributes and one or more child elements.<br>
 * This class cannot be instanced because it is abstract. Instead you must 
 * instance concrete class that represents concrete HTML element 
 * (eg. Div).<br>
 * This class provides methods for adding child elements and setting 
 * attributes.
 * 
 * @author Matjaž Cerkvenik
 *
 */
public abstract class HtmlElement {
	
	// http://www.w3schools.com/tags/default.asp
	
	/* GLOBAL ATTRIBUTES */
	/** Unique id for an element */
	public static final String ATTR_ID = "id";
	
	/** One or more classnames for an element (refers to a class in a style sheet) */
	public static final String ATTR_CLASS = "class";
	
	/** Language of the element's content */
	public static final String ATTR_LANG = "lang";
	
	/** Inline CSS style for an element */
	public static final String ATTR_STYLE = "style";
	
	/** Information about an element */
	public static final String ATTR_TITLE = "title";
	
	/* EVENT ATTRIBUTES */
	/** Fires after the page is finished loading */
	public static final String ATTR_ONLOAD = "onload";
	
	/** Fires once a page has unloaded (or the browser window has been closed) */
	public static final String ATTR_ONUNLOAD = "onunload";
	
	/** Fires on a mouse click on the element */
	public static final String ATTR_ONCLICK = "onclick";
	
	/** Fires when a mouse button is pressed down on an element */
	public static final String ATTR_ONMOUSEDOWN = "onmousedown";
	
	/** Fires when the mouse pointer moves out of an element */
	public static final String ATTR_ONMOUSEOUT = "onmouseout";
	
	/** Fires when the mouse pointer moves over an element */
	public static final String ATTR_ONMOUSEOVER = "onmouseover";
	
	/** Fires when a mouse button is released over an element */
	public static final String ATTR_ONMOUSEUP = "onmouseup";
	
	/* list of attributes of this element */
	private Map<String, String> attributes = null;
	
	/* list of child elements */
	private List<HtmlElement> elements = null;
	
	/** a counter of elements; used for automatic assigning of IDs */
	public static int elementCounter = 0;
	
	/**
	 * Return name of HTML element.
	 * @return name
	 */
	public abstract String getElName();
	
	/**
	 * Get element id
	 * @return id
	 */
	public String getId() {
		return attributes.get(ATTR_ID);
	}

	/**
	 * Set element id.
	 * @param id
	 */
	public void setId(String id) {
		addAttribute(ATTR_ID, id);
	}



	/**
	 * Add child element
	 * @param e
	 * @return HtmlElement
	 */
	public HtmlElement addElement(HtmlElement e) {
		if (elements == null) {
			elements = new ArrayList<HtmlElement>();
		}
		elements.add(e);
		return this;

	}
	
	
	/**
	 * Get all child elements
	 * @return elements
	 */
	public List<HtmlElement> getElements() {
		return elements;
	}



	/**
	 * Add attribute to element. If attribute with the same name 
	 * already exist, its value will be overwritten with new one.
	 * @param attrName
	 * @param attrValue
	 */
	public boolean addAttribute(String attrName, String attrValue) {
		if (attributes == null) {
			attributes = new HashMap<String, String>();
		}
		attributes.put(attrName, attrValue);
		return true;
	}
	
	/**
	 * Return all attributes
	 * @return attributes
	 */
	public Map<String, String> getAttributes() {
		return attributes;
	}
	
//	public void applyStyle(CssStyle cs) {
//		// add style to the style element in head
//		// assign id attribute
//	}
	
	/**
	 * Return string representation of all attributes in key="value" format.
	 * If no attributes are found, empty string is returned.
	 * @return attributes
	 */
	public String getAttributesAsString() {
		if (attributes == null || attributes.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (String key : attributes.keySet()) {
			sb.append(key + "=\"" + attributes.get(key) + "\" ");
		}
		return " " + sb.toString();
	}
	
	/**
	 * Return string representation of elements.
	 * @return elements
	 */
	public String getElementsAsString() {
		if (elements == null || elements.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < elements.size(); i++) {
			sb.append(elements.get(i).toString());
		}
		return sb.toString();
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<").append(getElName());
		sb.append(getAttributesAsString());
		sb.append(">");
		sb.append(getElementsAsString());
		sb.append("</").append(getElName()).append(">\n");
		return sb.toString();
	}
	
	
}
