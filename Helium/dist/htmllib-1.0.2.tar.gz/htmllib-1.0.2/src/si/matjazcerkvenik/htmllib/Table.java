package si.matjazcerkvenik.htmllib;


/**
 * This class represents <code>&lt;table&gt;</code> element.<br>
 * It should accept only <code>&lt;tr&gt;</code> element.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Table extends HtmlElement {
	
	public static final String ATTR_BORDER = "border";
	
	@Override
	public String getElName() {
		return "table";
	}
	
	/**
	 * Default constructor for HTML table.
	 */
	public Table() {
	}
	
	public int getBorder() {
		return Integer.parseInt(getAttributes().get(ATTR_BORDER));
	}

	public void setBorder(int border) {
		addAttribute(ATTR_BORDER, Integer.toString(border));
	}
	
}
