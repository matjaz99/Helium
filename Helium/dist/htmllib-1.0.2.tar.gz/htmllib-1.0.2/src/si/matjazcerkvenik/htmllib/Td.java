package si.matjazcerkvenik.htmllib;

/**
 * This element must be used in conjunction with table and tr element.
 * 
 * @author matjaz
 *
 */
public class Td extends HtmlElement {
	
	@Override
	public String getElName() {
		return "td";
	}
	
	
}
