package si.matjazcerkvenik.htmllib;

/**
 * This class represents <code>&lt;div&gt;</code> element. This element 
 * accepts any element as child element. Usually it is used as wrapper for 
 * other elements.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Div extends HtmlElement {
	
	public Div() {
		setId("e" + elementCounter++);
	}
	
	public Div(HtmlElement e) {
		addElement(e);
		setId("e" + elementCounter++);
	}
	
	public Div(HtmlElement... eList) {
		for (int i = 0; i < eList.length; i++) {
			addElement(eList[i]);
		}
		setId("e" + elementCounter++);
	}
	
	@Override
	public String getElName() {
		return "div";
	}
	
}
