package si.matjazcerkvenik.htmllib;

/**
 * This class represents <code>&lt;b&gt;</code> element.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Bold extends HtmlElement {
	
	public Bold() {
	}
	
	public Bold(String text) {
		addElement(new StringElement(text));
	}
	
	@Override
	public String getElName() {
		return "b";
	}
	
}
