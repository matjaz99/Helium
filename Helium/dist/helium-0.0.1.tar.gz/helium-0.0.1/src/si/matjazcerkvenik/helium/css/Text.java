package si.matjazcerkvenik.helium.css;

public class Text {
	
	
	
	public static final String FONT_STYLE_NORMAL = "normal";
	public static final String FONT_STYLE_ITALIC = "italic";
	public static final String FONT_STYLE_OBLIQUE = "oblique";
	public static final String FONT_STYLE_INHERIT = "inherit";
	
	public static final String FONT_WEIGHT_NORMAL = "normal";
	public static final String FONT_WEIGHT_BOLD = "bold";
	public static final String FONT_WEIGHT_BOLDER = "bolder";
	public static final String FONT_WEIGHT_LIGHTER = "lighter";
	public static final String FONT_WEIGHT_INHERIT = "inherit";
	
	public static final String TEXT_ALIGN_LEFT = "left";
	public static final String TEXT_ALIGN_RIGHT = "right";
	public static final String TEXT_ALIGN_CENTER = "center";
	public static final String TEXT_ALIGN_JUSTIFY = "justify";
	
	public static final String TEXT_DECORATION_NONE = "none";
	public static final String TEXT_DECORATION_UNDERLINE = "underline";
	public static final String TEXT_DECORATION_OVERLINE = "overline";
	public static final String TEXT_DECORATION_LINE_THROUGH = "line-through";
	public static final String TEXT_DECORATION_BLINK = "blink";
	public static final String TEXT_DECORATION_INHERIT = "inherit";
	
}
