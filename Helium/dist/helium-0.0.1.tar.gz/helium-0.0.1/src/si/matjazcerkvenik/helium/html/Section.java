package si.matjazcerkvenik.helium.html;

import si.matjazcerkvenik.helium.HtmlElement;

public class Section extends HtmlElement {
	
	@Override
	public String getName() {
		return "section";
	}
	
}
