package si.matjazcerkvenik.helium.html;

import si.matjazcerkvenik.helium.HtmlElement;

public class Figure extends HtmlElement {
	
	@Override
	public String getName() {
		return "figure";
	}
	
}
