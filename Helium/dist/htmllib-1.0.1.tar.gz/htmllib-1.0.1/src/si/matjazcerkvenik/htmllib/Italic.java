package si.matjazcerkvenik.htmllib;

/**
 * This class represents <code>&lt;i&gt;</code> element.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Italic extends HtmlElement {
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<i");
		sb.append(getAttributesAsString());
		sb.append(">");
		sb.append(getElementsAsString());
		sb.append("</i>");
		return sb.toString();
	}
	
}
