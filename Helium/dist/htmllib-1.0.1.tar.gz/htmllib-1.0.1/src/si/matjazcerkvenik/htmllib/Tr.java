package si.matjazcerkvenik.htmllib;

import java.util.ArrayList;
import java.util.List;

public class Tr extends HtmlElement {
	
	private List<Td> cols = new ArrayList<Td>();
	
	public void setRow(List<Object> row) {
		
		for (int i = 0; i < row.size(); i++) {
			Td td = new Td();
//			td.setValue(row.get(i));
//			td.addHtmlElement((HtmlElement) row.get(i));
			cols.add(td);
		}
		
	}
	
	public void addEntry(Td entry) {
		cols.add(entry);
	}
	
	public List<Td> getCols() {
		return cols;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<tr>");
		for (int i = 0; i < cols.size(); i++) {
			sb.append(cols.get(i).toString());
		}
		sb.append("</tr>");
		return sb.toString();
	}
	
}
