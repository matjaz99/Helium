package si.matjazcerkvenik.htmllib.examples;

import si.matjazcerkvenik.htmllib.Body;
import si.matjazcerkvenik.htmllib.Head;
import si.matjazcerkvenik.htmllib.Heading;
import si.matjazcerkvenik.htmllib.HtmlDocument;

public class Test1 {
	
	public static void main(String[] args) {
				
		test1();
		
	}
	
	private static void test1() {
		
		Heading h1 = new Heading(1, "Hello world");
		
		Head head = new Head("Hello world example");
		Body body = new Body(h1);
		
		HtmlDocument doc = new HtmlDocument(head, body);
		
		System.out.println(doc);
		
	}
	
}
