package si.matjazcerkvenik.htmllib;

/**
 * This class represents <code>&lt;b&gt;</code> element.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Bold extends HtmlElement {
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<b");
		sb.append(getAttributesAsString());
		sb.append(">");
		sb.append(getElementsAsString());
		sb.append("</b>");
		return sb.toString();
	}
	
}
