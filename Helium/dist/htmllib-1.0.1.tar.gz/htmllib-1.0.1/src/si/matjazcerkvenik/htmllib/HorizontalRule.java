package si.matjazcerkvenik.htmllib;

/**
 * Simple <code>&lt;hr&gt;</code> element.<br>
 * This element cannot accept any child elements.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class HorizontalRule extends HtmlElement {
	
	@Override
	public String toString() {
		return "<hr" + getAttributesAsString() + "/>";
	}
	
}
