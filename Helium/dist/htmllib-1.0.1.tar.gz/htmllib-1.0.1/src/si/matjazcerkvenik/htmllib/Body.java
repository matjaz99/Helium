package si.matjazcerkvenik.htmllib;

/**
 * Representation of <code>&lt;body&gt;</code> element.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Body extends HtmlElement {
	
	/**
	 * Default constructor
	 */
	public Body() {
	}
	
	/**
	 * Constructor of <code>&lt;body&gt;</code> element. HtmlElement is 
	 * the first element in body. Other elements must be added with 
	 * <code>addElement(e)</code> method.
	 * @param e
	 */
	public Body(HtmlElement e) {
		addElement(e);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<body");
		sb.append(getAttributesAsString());
		sb.append(">");
		for (int i = 0; i < getElements().size(); i++) {
			sb.append(getElements().get(i).toString());
		}
		sb.append("</body>");
		return sb.toString();
	}

}
