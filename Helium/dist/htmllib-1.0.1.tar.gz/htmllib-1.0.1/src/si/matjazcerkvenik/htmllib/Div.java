package si.matjazcerkvenik.htmllib;

/**
 * This class represents <code>&lt;div&gt;</code> element. This element 
 * accepts any element as child element. Usually it is used as wrapper for 
 * other elements.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Div extends HtmlElement {
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("<div");
		sb.append(getAttributesAsString());
		sb.append(">");
		sb.append(getElementsAsString());
		sb.append("</div>");
		return sb.toString();
	}
	
}
