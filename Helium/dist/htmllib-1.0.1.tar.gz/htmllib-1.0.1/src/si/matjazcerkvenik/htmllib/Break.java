package si.matjazcerkvenik.htmllib;

/**
 * Simple line break element (<code>&lt;br&gt;</code>).<br>
 * This element cannot accept any child elements.
 * 
 * @author Matjaz Cerkvenik
 *
 */
public class Break extends HtmlElement {
	
	@Override
	public String toString() {
		return "<" + getAttributesAsString() + "br/>";
	}
	
}
